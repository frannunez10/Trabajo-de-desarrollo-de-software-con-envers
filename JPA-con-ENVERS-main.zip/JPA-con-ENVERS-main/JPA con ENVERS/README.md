Comenzamos a estudiar JPA y la implementación con Hibernate. (Proyecto de base )
1- Descargar el proyecto
2- Abrir en Intelligent Idea Community
3 - Este Proyecto utiliza gradle y la base de dato H2 en memoria para simplificar
